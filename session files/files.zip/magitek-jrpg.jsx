import { useState, useEffect, useRef } from "react";

// ─── FONTS ───────────────────────────────────────────────────────────────────
const fontLink = document.createElement("link");
fontLink.rel = "stylesheet";
fontLink.href = "https://fonts.googleapis.com/css2?family=Press+Start+2P&family=VT323:wght@400&display=swap";
document.head.appendChild(fontLink);

// ─── THEME ───────────────────────────────────────────────────────────────────
const T = {
  bg:        "#0a0d14",
  panel:     "#111827",
  border:    "#2a3a5a",
  gold:      "#e8b84b",
  amber:     "#c97c2a",
  steam:     "#7dd3c8",
  red:       "#e05555",
  green:     "#4ec97a",
  blue:      "#5b8dee",
  purple:    "#a070e0",
  gray:      "#4a5568",
  lightGray: "#8899aa",
  white:     "#e8edf5",
};

const css = `
  @keyframes flicker { 0%,100%{opacity:1} 50%{opacity:.85} }
  @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-4px)} }
  @keyframes shake { 0%,100%{transform:translateX(0)} 25%{transform:translateX(-4px)} 75%{transform:translateX(4px)} }
  @keyframes fadeIn { from{opacity:0;transform:translateY(8px)} to{opacity:1;transform:translateY(0)} }
  @keyframes pulse { 0%,100%{box-shadow:0 0 6px ${T.gold}} 50%{box-shadow:0 0 18px ${T.gold}} }
  @keyframes steamRise { 0%{transform:translateY(0) scale(1);opacity:.6} 100%{transform:translateY(-30px) scale(1.4);opacity:0} }
  @keyframes scanline { 0%{transform:translateY(-100%)} 100%{transform:translateY(100vh)} }
  .shake { animation: shake 0.3s ease; }
  .fadeIn { animation: fadeIn 0.4s ease forwards; }
`;
const styleEl = document.createElement("style");
styleEl.textContent = css;
document.head.appendChild(styleEl);

// ─── JOBS ────────────────────────────────────────────────────────────────────
const JOBS = {
  Knight:    { emoji:"⚔️",  color: T.gold,   hp:120, mp:20,  atk:18, def:14, mag:4,  spd:6,  skills:["Attack","Guard","Provoke"],        desc:"Iron-clad vanguard. High DEF, protects allies." },
  Machinist: { emoji:"🔧",  color: T.steam,  hp:85,  mp:30,  atk:12, def:8,  mag:10, spd:10, skills:["Attack","Drill Shot","Grenade"],    desc:"Tinkers with gadgets. Balanced damage dealer." },
  Arcanist:  { emoji:"📡",  color: T.purple, hp:65,  mp:90,  atk:6,  def:5,  mag:20, spd:7,  skills:["Attack","Voltaic Bolt","Hex Field"],desc:"Channels magitek energy. Glass cannon mage." },
  Medic:     { emoji:"💉",  color: T.green,  hp:80,  mp:70,  atk:8,  def:9,  mag:12, spd:8,  skills:["Attack","Aethersalve","Revive"],    desc:"Battlefield surgeon. Heals and supports party." },
  Rogue:     { emoji:"🗡️",  color: T.amber,  hp:75,  mp:40,  atk:16, def:7,  mag:8,  spd:14, skills:["Attack","Back Stab","Smoke Bomb"],  desc:"Swift and cunning. High speed & burst damage." },
  Gunner:    { emoji:"🔫",  color: T.blue,   hp:90,  mp:35,  atk:14, def:8,  mag:9,  spd:11, skills:["Attack","Burst Fire","Aimed Shot"], desc:"Ranged specialist. Consistent physical damage." },
};

const SKILLS = {
  "Attack":      { type:"dmg",  power:1.0,  mpCost:0,  target:"enemy",  desc:"Basic attack" },
  "Guard":       { type:"buff", power:0,    mpCost:6,  target:"self",   desc:"Raise DEF this turn", effect:"def_up" },
  "Provoke":     { type:"taunt",power:0,    mpCost:8,  target:"self",   desc:"Draw enemy attacks to self", effect:"taunt" },
  "Drill Shot":  { type:"dmg",  power:1.3,  mpCost:10, target:"enemy",  desc:"Armor-piercing shot" },
  "Grenade":     { type:"dmg",  power:0.9,  mpCost:14, target:"all",    desc:"Hits all enemies" },
  "Voltaic Bolt":{ type:"dmg",  power:1.8,  mpCost:18, target:"enemy",  desc:"Lightning magitek burst" },
  "Hex Field":   { type:"debuff",power:0,   mpCost:22, target:"enemy",  desc:"Reduce enemy ATK", effect:"atk_down" },
  "Aethersalve": { type:"heal", power:1.4,  mpCost:16, target:"ally",   desc:"Restore HP to one ally" },
  "Revive":      { type:"revive",power:0,   mpCost:30, target:"ally",   desc:"Revive a fallen ally with 30% HP" },
  "Back Stab":   { type:"dmg",  power:1.6,  mpCost:12, target:"enemy",  desc:"Crit-weighted strike" },
  "Smoke Bomb":  { type:"debuff",power:0,   mpCost:10, target:"all",    desc:"Reduce all enemy SPD", effect:"spd_down" },
  "Burst Fire":  { type:"dmg",  power:1.1,  mpCost:12, target:"enemy",  desc:"Multi-hit ranged attack" },
  "Aimed Shot":  { type:"dmg",  power:1.5,  mpCost:16, target:"enemy",  desc:"High accuracy single hit" },
};

// ─── ENEMIES ─────────────────────────────────────────────────────────────────
const ENEMY_TEMPLATES = [
  { name:"Steam Golem",    emoji:"🤖", hp:80,  atk:12, def:8,  mag:4,  spd:4,  reward:{xp:30,gold:20}, color:T.steam },
  { name:"Aether Wraith",  emoji:"👻", hp:55,  atk:8,  def:4,  mag:16, spd:9,  reward:{xp:25,gold:15}, color:T.purple },
  { name:"Iron Drone",     emoji:"⚙️", hp:70,  atk:14, def:10, mag:2,  spd:6,  reward:{xp:28,gold:18}, color:T.gray },
  { name:"Magitek Hound",  emoji:"🐺", hp:65,  atk:16, def:6,  mag:5,  spd:12, reward:{xp:32,gold:22}, color:T.amber },
  { name:"Hex Turret",     emoji:"🗼", hp:90,  atk:10, def:14, mag:12, spd:3,  reward:{xp:35,gold:25}, color:T.blue },
];

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function roll(min, max) { return Math.floor(Math.random() * (max - min + 1)) + min; }
function calcDmg(atk, def, power = 1.0) {
  const base = Math.max(1, atk - Math.floor(def * 0.4));
  return Math.floor(base * power * (0.9 + Math.random() * 0.2));
}
function calcHeal(mag, power = 1.0) {
  return Math.floor(mag * 2.5 * power * (0.9 + Math.random() * 0.2));
}

function makeChar(name, jobKey, idx) {
  const job = JOBS[jobKey];
  return {
    id: idx, name, job: jobKey,
    maxHp: job.hp, hp: job.hp,
    maxMp: job.mp, mp: job.mp,
    atk: job.atk, def: job.def, mag: job.mag, spd: job.spd,
    xp: 0, level: 1,
    status: null, // buff/debuff tracking
    alive: true,
  };
}

function makeEnemy(template) {
  return { ...template, maxHp: template.hp, alive: true, id: Math.random(), status: null };
}

// ─── PIXEL ART SPRITES (CSS-drawn) ───────────────────────────────────────────
function CharSprite({ job, size = 48, animate = false }) {
  const j = JOBS[job];
  return (
    <div style={{
      width: size, height: size, display:"flex", alignItems:"center", justifyContent:"center",
      fontSize: size * 0.55,
      animation: animate ? "float 2s ease-in-out infinite" : "none",
      filter: `drop-shadow(0 0 6px ${j.color}88)`,
    }}>
      {j.emoji}
    </div>
  );
}

function EnemySprite({ enemy, size = 56, shake = false }) {
  return (
    <div className={shake ? "shake" : ""} style={{
      width: size, height: size, display:"flex", alignItems:"center", justifyContent:"center",
      fontSize: size * 0.65,
      filter: `drop-shadow(0 0 8px ${enemy.color}99)`,
    }}>
      {enemy.emoji}
    </div>
  );
}

// ─── UI COMPONENTS ────────────────────────────────────────────────────────────
function PixelBox({ children, style = {}, glow }) {
  return (
    <div style={{
      background: T.panel,
      border: `2px solid ${T.border}`,
      boxShadow: glow ? `0 0 12px ${glow}66, inset 0 0 20px #0004` : `inset 0 0 20px #0004`,
      padding: "12px",
      imageRendering: "pixelated",
      ...style,
    }}>
      {children}
    </div>
  );
}

function HPBar({ current, max, color = T.green }) {
  const pct = Math.max(0, current / max);
  const barColor = pct > 0.5 ? T.green : pct > 0.25 ? T.gold : T.red;
  return (
    <div style={{ width:"100%", height:8, background:"#1a2030", border:`1px solid ${T.border}`, borderRadius:0 }}>
      <div style={{
        width:`${pct*100}%`, height:"100%", background: barColor,
        transition:"width 0.3s ease",
        boxShadow: `0 0 4px ${barColor}`,
      }}/>
    </div>
  );
}

function MPBar({ current, max }) {
  const pct = Math.max(0, current / max);
  return (
    <div style={{ width:"100%", height:6, background:"#1a2030", border:`1px solid ${T.border}`, borderRadius:0 }}>
      <div style={{
        width:`${pct*100}%`, height:"100%", background: T.blue,
        transition:"width 0.3s ease",
        boxShadow: `0 0 4px ${T.blue}`,
      }}/>
    </div>
  );
}

function Txt({ children, size = 10, color = T.white, style = {}, font = "Press Start 2P" }) {
  return (
    <span style={{ fontFamily:`'${font}', monospace`, fontSize: size, color, lineHeight:1.6, ...style }}>
      {children}
    </span>
  );
}

function VT({ children, size = 18, color = T.white, style = {} }) {
  return (
    <span style={{ fontFamily:"'VT323', monospace", fontSize: size, color, lineHeight:1.4, ...style }}>
      {children}
    </span>
  );
}

function Btn({ children, onClick, disabled, color = T.gold, small }) {
  const [hover, setHover] = useState(false);
  return (
    <button
      onClick={onClick} disabled={disabled}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      style={{
        background: disabled ? T.gray : hover ? color : "transparent",
        border: `2px solid ${disabled ? T.gray : color}`,
        color: disabled ? T.lightGray : hover ? T.bg : color,
        fontFamily:"'Press Start 2P', monospace",
        fontSize: small ? 8 : 9,
        padding: small ? "5px 8px" : "8px 14px",
        cursor: disabled ? "not-allowed" : "pointer",
        transition:"all 0.15s",
        imageRendering:"pixelated",
        whiteSpace:"nowrap",
      }}
    >
      {children}
    </button>
  );
}

// ─── SCREENS ──────────────────────────────────────────────────────────────────

// TITLE SCREEN
function TitleScreen({ onStart }) {
  const [tick, setTick] = useState(0);
  useEffect(() => {
    const t = setInterval(() => setTick(p => p+1), 600);
    return () => clearInterval(t);
  }, []);
  return (
    <div style={{
      minHeight:"100vh", background: T.bg,
      display:"flex", flexDirection:"column", alignItems:"center", justifyContent:"center",
      position:"relative", overflow:"hidden",
      fontFamily:"'Press Start 2P', monospace",
    }}>
      {/* Scanline overlay */}
      <div style={{
        position:"absolute", inset:0, pointerEvents:"none",
        background:"repeating-linear-gradient(0deg, transparent, transparent 2px, #00000018 2px, #00000018 4px)",
      }}/>
      {/* Steam particles */}
      {[...Array(6)].map((_,i) => (
        <div key={i} style={{
          position:"absolute",
          left:`${15 + i*13}%`, bottom:"10%",
          width:6, height:6, borderRadius:"50%",
          background: T.steam, opacity:0.4,
          animation:`steamRise ${2+i*0.4}s ease-out infinite`,
          animationDelay:`${i*0.3}s`,
        }}/>
      ))}
      <div style={{ textAlign:"center", animation:"fadeIn 1s ease forwards" }}>
        {/* Gear decorations */}
        <div style={{ fontSize:28, marginBottom:8, letterSpacing:16, opacity:0.6 }}>⚙️ ⚙️ ⚙️</div>
        <div style={{ marginBottom:4 }}>
          <Txt size={11} color={T.steam}>CHRONICLES OF</Txt>
        </div>
        <div style={{
          fontSize:28, fontFamily:"'Press Start 2P', monospace",
          color: T.gold,
          textShadow:`0 0 20px ${T.gold}, 0 0 40px ${T.amber}`,
          animation:"flicker 3s ease-in-out infinite",
          marginBottom:4, lineHeight:1.4,
        }}>
          AETHERMARCH
        </div>
        <div style={{ marginBottom:32 }}>
          <Txt size={8} color={T.amber}>A MAGITEK ODYSSEY</Txt>
        </div>
        <div style={{ marginBottom:48, opacity:0.7 }}>
          <VT size={20} color={T.lightGray}>
            In a world where steam and sorcery collide,<br/>
            four souls must stop the Hex Engine from consuming all life.
          </VT>
        </div>
        <div style={{ opacity: tick % 2 === 0 ? 1 : 0, transition:"opacity 0.3s" }}>
          <Txt size={9} color={T.gold}>▶ PRESS START</Txt>
        </div>
        <div style={{ marginTop:24 }}>
          <Btn onClick={onStart} color={T.gold}>NEW GAME</Btn>
        </div>
      </div>
    </div>
  );
}

// JOB SELECT SCREEN
function JobSelectScreen({ onConfirm }) {
  const DEFAULT_NAMES = ["Vex", "Lyra", "Cael", "Mira"];
  const [party, setParty] = useState([
    { name:"Vex",  job:"Knight"    },
    { name:"Lyra", job:"Arcanist"  },
    { name:"Cael", job:"Machinist" },
    { name:"Mira", job:"Medic"     },
  ]);
  const [selected, setSelected] = useState(0);

  const jobKeys = Object.keys(JOBS);

  function setJob(idx, job) {
    setParty(p => p.map((c,i) => i===idx ? {...c, job} : c));
  }
  function setName(idx, name) {
    setParty(p => p.map((c,i) => i===idx ? {...c, name} : c));
  }

  return (
    <div style={{
      minHeight:"100vh", background:T.bg, padding:24,
      fontFamily:"'Press Start 2P', monospace",
      backgroundImage:`radial-gradient(ellipse at 20% 50%, #1a2540 0%, transparent 60%),
                       radial-gradient(ellipse at 80% 50%, #1a1a30 0%, transparent 60%)`,
    }}>
      <div style={{ textAlign:"center", marginBottom:24 }}>
        <Txt size={14} color={T.gold}>ASSEMBLE YOUR CREW</Txt>
        <div style={{ marginTop:8 }}>
          <VT size={18} color={T.lightGray}>Choose jobs for your 4-person party</VT>
        </div>
      </div>

      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:16, maxWidth:700, margin:"0 auto 24px" }}>
        {party.map((char, idx) => (
          <PixelBox key={idx} style={{ cursor:"pointer", outline: selected===idx ? `2px solid ${T.gold}` : "none" }}
            glow={selected===idx ? T.gold : null}
            onClick={() => setSelected(idx)}>
            <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:10 }}>
              <CharSprite job={char.job} size={40} animate={selected===idx}/>
              <div>
                <input
                  value={char.name}
                  onChange={e => setName(idx, e.target.value)}
                  onClick={e => e.stopPropagation()}
                  style={{
                    background:"transparent", border:"none", borderBottom:`1px solid ${T.gold}`,
                    color:T.gold, fontFamily:"'Press Start 2P', monospace", fontSize:9,
                    width:80, outline:"none", marginBottom:4,
                  }}
                />
                <div>
                  <Txt size={7} color={JOBS[char.job].color}>{char.job}</Txt>
                </div>
              </div>
            </div>
            <VT size={15} color={T.lightGray}>{JOBS[char.job].desc}</VT>
            <div style={{ marginTop:8, display:"flex", gap:4, flexWrap:"wrap" }}>
              <Txt size={7} color={T.gray}>HP:{JOBS[char.job].hp} </Txt>
              <Txt size={7} color={T.gray}>ATK:{JOBS[char.job].atk} </Txt>
              <Txt size={7} color={T.gray}>MAG:{JOBS[char.job].mag} </Txt>
              <Txt size={7} color={T.gray}>SPD:{JOBS[char.job].spd}</Txt>
            </div>
          </PixelBox>
        ))}
      </div>

      {/* Job picker for selected */}
      <PixelBox style={{ maxWidth:700, margin:"0 auto 24px" }}>
        <div style={{ marginBottom:10 }}>
          <Txt size={8} color={T.steam}>CHANGE JOB: {party[selected].name}</Txt>
        </div>
        <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
          {jobKeys.map(j => (
            <button key={j} onClick={() => setJob(selected, j)} style={{
              background: party[selected].job === j ? JOBS[j].color : "transparent",
              border:`2px solid ${JOBS[j].color}`,
              color: party[selected].job === j ? T.bg : JOBS[j].color,
              fontFamily:"'Press Start 2P', monospace", fontSize:8,
              padding:"6px 10px", cursor:"pointer",
            }}>
              {JOBS[j].emoji} {j}
            </button>
          ))}
        </div>
      </PixelBox>

      <div style={{ textAlign:"center" }}>
        <Btn onClick={() => onConfirm(party)} color={T.gold}>BEGIN JOURNEY ▶</Btn>
      </div>
    </div>
  );
}

// WORLD MAP
function WorldMapScreen({ party, onBattle, gold, xp }) {
  const locations = [
    { name:"Ironhaven City",   emoji:"🏙️", desc:"The smog-choked capital. Seek clues here.", x:25, y:35, type:"town" },
    { name:"Gearwood Forest",  emoji:"🌲", desc:"Ancient trees laced with magitek vines.",   x:55, y:25, type:"battle" },
    { name:"The Hex Foundry",  emoji:"🏭", desc:"Danger lurks in the dark iron depths.",      x:75, y:60, type:"battle" },
    { name:"Aether Ruins",     emoji:"🗿", desc:"Crumbling towers humming with old power.",   x:40, y:65, type:"battle" },
    { name:"Sky Docks",        emoji:"🚀", desc:"Airships departing to the unknown west.",    x:15, y:70, type:"battle" },
  ];
  const [hover, setHover] = useState(null);

  return (
    <div style={{
      minHeight:"100vh", background:T.bg,
      backgroundImage:`
        radial-gradient(ellipse at 30% 40%, #1a2a1a 0%, transparent 50%),
        radial-gradient(ellipse at 70% 70%, #1a1a2a 0%, transparent 50%),
        radial-gradient(ellipse at 50% 20%, #2a1a10 0%, transparent 40%)
      `,
      padding:20, fontFamily:"'Press Start 2P', monospace",
    }}>
      <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
        <Txt size={12} color={T.gold}>WORLD MAP</Txt>
        <div style={{ display:"flex", gap:16 }}>
          <Txt size={8} color={T.amber}>⚙ {gold}G</Txt>
        </div>
      </div>

      {/* Party bar */}
      <PixelBox style={{ marginBottom:16, display:"flex", gap:12, flexWrap:"wrap" }}>
        {party.map(c => (
          <div key={c.id} style={{ display:"flex", alignItems:"center", gap:6, opacity: c.alive ? 1 : 0.4 }}>
            <CharSprite job={c.job} size={28}/>
            <div>
              <Txt size={7} color={JOBS[c.job].color}>{c.name}</Txt>
              <div style={{ width:60, marginTop:2 }}><HPBar current={c.hp} max={c.maxHp}/></div>
              <Txt size={6} color={T.lightGray}>{c.hp}/{c.maxHp}</Txt>
            </div>
          </div>
        ))}
      </PixelBox>

      {/* Map area */}
      <PixelBox style={{ position:"relative", height:320, marginBottom:16, overflow:"hidden" }}>
        {/* Grid lines */}
        <div style={{
          position:"absolute", inset:0, opacity:0.07,
          backgroundImage:`repeating-linear-gradient(0deg,${T.steam} 0,${T.steam} 1px,transparent 0,transparent 40px),
                           repeating-linear-gradient(90deg,${T.steam} 0,${T.steam} 1px,transparent 0,transparent 40px)`,
        }}/>
        {locations.map((loc, i) => (
          <div key={i} style={{
            position:"absolute", left:`${loc.x}%`, top:`${loc.y}%`,
            transform:"translate(-50%,-50%)",
            cursor:"pointer",
            animation: hover===i ? "pulse 1s infinite" : "none",
          }}
            onMouseEnter={() => setHover(i)}
            onMouseLeave={() => setHover(null)}
            onClick={() => loc.type === "battle" && onBattle(loc)}
          >
            <div style={{
              fontSize:24,
              filter:`drop-shadow(0 0 ${hover===i?10:4}px ${loc.type==="battle"?T.red:T.gold})`,
              transition:"filter 0.2s",
            }}>{loc.emoji}</div>
            {hover===i && (
              <div style={{
                position:"absolute", top:"110%", left:"50%", transform:"translateX(-50%)",
                background:T.panel, border:`1px solid ${T.border}`, padding:"6px 8px",
                whiteSpace:"nowrap", zIndex:10,
              }}>
                <Txt size={7} color={T.gold}>{loc.name}</Txt>
                <div><VT size={14} color={T.lightGray}>{loc.desc}</VT></div>
                {loc.type==="battle" && <div style={{marginTop:4}}><Txt size={6} color={T.red}>⚔ ENTER AREA</Txt></div>}
              </div>
            )}
          </div>
        ))}
      </PixelBox>

      <div style={{ textAlign:"center" }}>
        <VT size={18} color={T.lightGray}>Click a ⚔ location to enter battle</VT>
      </div>
    </div>
  );
}

// BATTLE SCREEN
function BattleScreen({ party: initialParty, location, onVictory, onDefeat }) {
  const enemyCount = roll(1, 3);
  const [enemies, setEnemies] = useState(() =>
    Array.from({length: enemyCount}, () =>
      makeEnemy(ENEMY_TEMPLATES[roll(0, ENEMY_TEMPLATES.length-1)])
    )
  );
  const [party, setParty] = useState(() => initialParty.map(c => ({...c})));
  const [turn, setTurn] = useState(0); // index into turn order
  const [phase, setPhase] = useState("player"); // player | enemy | end
  const [log, setLog] = useState([`⚙ Entered ${location.name}! ${enemyCount} enem${enemyCount>1?"ies":"y"} appear!`]);
  const [selectedSkill, setSelectedSkill] = useState(null);
  const [selectedTarget, setSelectedTarget] = useState(null);
  const [shakeEnemy, setShakeEnemy] = useState(null);
  const [shakeChar, setShakeChar] = useState(null);
  const [aiLoading, setAiLoading] = useState(false);
  const [battleOver, setBattleOver] = useState(null); // "win"|"lose"
  const logRef = useRef();

  useEffect(() => {
    if (logRef.current) logRef.current.scrollTop = logRef.current.scrollHeight;
  }, [log]);

  // Current acting character
  const aliveParty = party.filter(c => c.alive);
  const currentChar = aliveParty[turn % Math.max(1, aliveParty.length)];
  const currentJob = currentChar ? JOBS[currentChar.job] : null;
  const currentSkills = currentJob ? currentJob.skills : [];

  function addLog(msg) { setLog(l => [...l, msg]); }

  async function getAIFlavor(action, actor, target) {
    setAiLoading(true);
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method:"POST",
        headers:{"Content-Type":"application/json"},
        body: JSON.stringify({
          model:"claude-sonnet-4-20250514",
          max_tokens:80,
          messages:[{
            role:"user",
            content:`You are a JRPG battle narrator for a steampunk/magitek fantasy game. Write ONE punchy battle line (max 12 words) for: ${actor} uses ${action} on ${target}. Be dramatic and fun, steampunk flavor.`
          }]
        })
      });
      const data = await res.json();
      const text = data.content?.[0]?.text ?? "";
      if (text) addLog(`✨ ${text}`);
    } catch(e) {}
    setAiLoading(false);
  }

  function doPlayerAction(skillName, targetIdx, targetType) {
    if (!currentChar || battleOver) return;
    const skill = SKILLS[skillName];
    if (!skill) return;
    if (skill.mpCost > currentChar.mp) { addLog(`❌ Not enough MP!`); return; }

    // Deduct MP
    setParty(p => p.map(c => c.id===currentChar.id ? {...c, mp: c.mp - skill.mpCost} : c));

    let dmg = 0, healAmt = 0;

    if (skill.type === "dmg") {
      if (skill.target === "all") {
        // Hit all enemies
        let newEnemies = [...enemies];
        enemies.forEach((en, i) => {
          if (!en.alive) return;
          dmg = calcDmg(currentChar.atk + currentChar.mag * 0.3, en.def, skill.power);
          newEnemies[i] = {...en, hp: Math.max(0, en.hp - dmg), alive: en.hp - dmg > 0};
        });
        setEnemies(newEnemies);
        addLog(`💥 ${currentChar.name} uses ${skillName} — hits all enemies!`);
        setShakeEnemy("all");
        setTimeout(() => setShakeEnemy(null), 400);
      } else {
        dmg = calcDmg(currentChar.atk + currentChar.mag * 0.2, enemies[targetIdx].def, skill.power);
        setEnemies(en => en.map((e,i) => i===targetIdx ? {...e, hp:Math.max(0,e.hp-dmg), alive:e.hp-dmg>0} : e));
        addLog(`⚔ ${currentChar.name} → ${enemies[targetIdx].name}: -${dmg} HP`);
        setShakeEnemy(targetIdx);
        setTimeout(() => setShakeEnemy(null), 400);
      }
      getAIFlavor(skillName, currentChar.name, targetIdx !== null ? enemies[targetIdx]?.name : "enemies");
    } else if (skill.type === "heal") {
      healAmt = calcHeal(currentChar.mag, skill.power);
      setParty(p => p.map(c => c.id===targetIdx ? {...c, hp:Math.min(c.maxHp, c.hp+healAmt)} : c));
      const target = party.find(c=>c.id===targetIdx);
      addLog(`💚 ${currentChar.name} heals ${target?.name}: +${healAmt} HP`);
    } else if (skill.type === "revive") {
      setParty(p => p.map(c => c.id===targetIdx ? {...c, hp:Math.floor(c.maxHp*0.3), alive:true} : c));
      const target = party.find(c=>c.id===targetIdx);
      addLog(`✨ ${currentChar.name} revives ${target?.name}!`);
    } else {
      addLog(`🔧 ${currentChar.name} uses ${skillName}!`);
    }

    setSelectedSkill(null);
    setSelectedTarget(null);
    advanceTurn();
  }

  function advanceTurn() {
    // Check win/lose
    setTimeout(() => {
      const aliveEn = enemies.filter(e => e.alive);
      const aliveP = party.filter(c => c.alive);
      if (aliveEn.length === 0) { setBattleOver("win"); return; }
      if (aliveP.length === 0) { setBattleOver("lose"); return; }

      // Enemy turn
      setPhase("enemy");
      setTimeout(() => {
        const en = aliveEn[roll(0, aliveEn.length-1)];
        const target = aliveP[roll(0, aliveP.length-1)];
        const dmg = calcDmg(en.atk, target.def);
        setParty(p => p.map(c => c.id===target.id ? {...c, hp:Math.max(0,c.hp-dmg), alive:c.hp-dmg>0} : c));
        addLog(`🤖 ${en.name} attacks ${target.name}: -${dmg} HP`);
        setShakeChar(target.id);
        setTimeout(() => setShakeChar(null), 400);

        // Check after enemy turn
        setTimeout(() => {
          setParty(prev => {
            const stillAlive = prev.filter(c => c.alive);
            if (stillAlive.length === 0) setBattleOver("lose");
            return prev;
          });
          setTurn(t => t + 1);
          setPhase("player");
        }, 600);
      }, 800);
    }, 300);
  }

  // Determine if we need a target selection
  const skillData = selectedSkill ? SKILLS[selectedSkill] : null;
  const needsTarget = skillData && (skillData.target === "enemy" || skillData.target === "ally");
  const targetingAllies = skillData && (skillData.target === "ally");

  const xpReward = enemies.reduce((s,e) => s + e.reward.xp, 0);
  const goldReward = enemies.reduce((s,e) => s + e.reward.gold, 0);

  if (battleOver === "win") {
    return (
      <div style={{
        minHeight:"100vh", background:T.bg, display:"flex", flexDirection:"column",
        alignItems:"center", justifyContent:"center", fontFamily:"'Press Start 2P', monospace",
      }}>
        <div className="fadeIn" style={{ textAlign:"center" }}>
          <div style={{ fontSize:48, marginBottom:16 }}>🏆</div>
          <Txt size={18} color={T.gold}>VICTORY!</Txt>
          <div style={{ marginTop:16, marginBottom:8 }}><Txt size={9} color={T.amber}>⚙ +{xpReward} XP</Txt></div>
          <div style={{ marginBottom:24 }}><Txt size={9} color={T.gold}>💰 +{goldReward} Gold</Txt></div>
          <Btn onClick={() => onVictory(party, xpReward, goldReward)} color={T.gold}>CONTINUE ▶</Btn>
        </div>
      </div>
    );
  }

  if (battleOver === "lose") {
    return (
      <div style={{
        minHeight:"100vh", background:T.bg, display:"flex", flexDirection:"column",
        alignItems:"center", justifyContent:"center", fontFamily:"'Press Start 2P', monospace",
      }}>
        <div className="fadeIn" style={{ textAlign:"center" }}>
          <div style={{ fontSize:48, marginBottom:16 }}>💀</div>
          <Txt size={18} color={T.red}>DEFEATED</Txt>
          <div style={{ marginTop:16, marginBottom:24 }}>
            <VT size={20} color={T.lightGray}>Your party was overwhelmed...</VT>
          </div>
          <Btn onClick={onDefeat} color={T.red}>RETURN TO MAP</Btn>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      minHeight:"100vh", background:T.bg,
      backgroundImage:`radial-gradient(ellipse at 50% 100%, #1a0a0a 0%, transparent 60%)`,
      padding:16, fontFamily:"'Press Start 2P', monospace",
    }}>
      {/* Header */}
      <div style={{ textAlign:"center", marginBottom:12 }}>
        <Txt size={9} color={T.steam}>⚙ {location.name} ⚙</Txt>
      </div>

      {/* Enemy row */}
      <PixelBox style={{ marginBottom:12, display:"flex", justifyContent:"center", gap:24, flexWrap:"wrap" }}>
        {enemies.map((en, i) => (
          <div key={en.id} style={{
            textAlign:"center", opacity: en.alive ? 1 : 0.2,
            cursor: !en.alive ? "default" : (needsTarget && !targetingAllies ? "pointer" : "default"),
            outline: selectedTarget===i && !targetingAllies ? `2px solid ${T.red}` : "none",
            padding:8,
          }}
            onClick={() => {
              if (needsTarget && !targetingAllies && en.alive) {
                doPlayerAction(selectedSkill, i, "enemy");
              }
            }}
          >
            <EnemySprite enemy={en} shake={shakeEnemy===i || shakeEnemy==="all"}/>
            <div style={{ marginTop:4 }}>
              <Txt size={7} color={en.color}>{en.name}</Txt>
            </div>
            <div style={{ width:80, margin:"4px auto 2px" }}><HPBar current={en.hp} max={en.maxHp}/></div>
            <Txt size={6} color={T.lightGray}>{en.hp}/{en.maxHp}</Txt>
          </div>
        ))}
      </PixelBox>

      {/* Battle log */}
      <PixelBox style={{ marginBottom:12, height:100, overflowY:"auto" }} ref={logRef}>
        {log.map((l,i) => (
          <div key={i} style={{ marginBottom:3 }}>
            <VT size={16} color={i===log.length-1 ? T.white : T.lightGray}>{l}</VT>
          </div>
        ))}
        {aiLoading && <VT size={16} color={T.steam}>✨ ...</VT>}
      </PixelBox>

      {/* Party row */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:8, marginBottom:12 }}>
        {party.map(c => (
          <PixelBox key={c.id}
            glow={currentChar?.id===c.id && phase==="player" ? T.gold : null}
            style={{
              opacity: c.alive ? 1 : 0.3,
              cursor: needsTarget && targetingAllies && c.alive ? "pointer" : "default",
              outline: selectedTarget===c.id && targetingAllies ? `2px solid ${T.green}` : "none",
            }}
            onClick={() => {
              if (needsTarget && targetingAllies && c.alive) {
                doPlayerAction(selectedSkill, c.id, "ally");
              }
            }}
          >
            <div className={shakeChar===c.id ? "shake" : ""}>
              <CharSprite job={c.job} size={28} animate={currentChar?.id===c.id}/>
            </div>
            <Txt size={6} color={JOBS[c.job].color}>{c.name}</Txt>
            <div style={{ marginTop:4 }}><HPBar current={c.hp} max={c.maxHp}/></div>
            <Txt size={6} color={T.lightGray}>{c.hp}/{c.maxHp}</Txt>
            <div style={{ marginTop:2 }}><MPBar current={c.mp} max={c.maxMp}/></div>
            <Txt size={6} color={T.blue}>{c.mp}MP</Txt>
          </PixelBox>
        ))}
      </div>

      {/* Skill panel */}
      {phase === "player" && currentChar && (
        <PixelBox glow={T.steam}>
          <div style={{ marginBottom:8, display:"flex", justifyContent:"space-between" }}>
            <Txt size={8} color={T.steam}>{currentChar.name}'s TURN</Txt>
            {selectedSkill && <Txt size={7} color={T.gold}>Select {targetingAllies?"ally":"enemy"} →</Txt>}
          </div>
          <div style={{ display:"flex", gap:8, flexWrap:"wrap" }}>
            {currentSkills.map(s => {
              const sk = SKILLS[s];
              const canAfford = sk && currentChar.mp >= sk.mpCost;
              return (
                <div key={s}>
                  <Btn
                    small
                    disabled={!canAfford}
                    color={selectedSkill===s ? T.gold : T.steam}
                    onClick={() => {
                      if (sk.target === "all" || sk.target === "self") {
                        // No target needed
                        if (sk.target === "self") {
                          doPlayerAction(s, currentChar.id, "ally");
                        } else {
                          doPlayerAction(s, null, "all");
                        }
                      } else {
                        setSelectedSkill(selectedSkill===s ? null : s);
                      }
                    }}
                  >
                    {s}
                    {sk.mpCost > 0 && <span style={{ color:T.blue }}> {sk.mpCost}MP</span>}
                  </Btn>
                  {selectedSkill===s && (
                    <div><VT size={13} color={T.lightGray}>{sk.desc}</VT></div>
                  )}
                </div>
              );
            })}
          </div>
        </PixelBox>
      )}
      {phase === "enemy" && (
        <PixelBox>
          <VT size={18} color={T.red}>Enemy turn...</VT>
        </PixelBox>
      )}
    </div>
  );
}

// ─── MAIN APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState("title"); // title | jobselect | map | battle
  const [party, setParty] = useState([]);
  const [gold, setGold] = useState(100);
  const [totalXp, setTotalXp] = useState(0);
  const [activeLocation, setActiveLocation] = useState(null);

  function handleJobConfirm(selections) {
    const chars = selections.map((s, i) => makeChar(s.name, s.job, i));
    setParty(chars);
    setScreen("map");
  }

  function handleBattle(location) {
    setActiveLocation(location);
    setScreen("battle");
  }

  function handleVictory(updatedParty, xpGain, goldGain) {
    setParty(updatedParty);
    setGold(g => g + goldGain);
    setTotalXp(x => x + xpGain);
    setScreen("map");
  }

  function handleDefeat() {
    // Restore partial HP and return to map
    setParty(p => p.map(c => ({...c, hp: Math.max(1, Math.floor(c.maxHp * 0.2)), alive: true})));
    setScreen("map");
  }

  if (screen === "title") return <TitleScreen onStart={() => setScreen("jobselect")}/>;
  if (screen === "jobselect") return <JobSelectScreen onConfirm={handleJobConfirm}/>;
  if (screen === "map") return <WorldMapScreen party={party} onBattle={handleBattle} gold={gold} xp={totalXp}/>;
  if (screen === "battle") return (
    <BattleScreen
      party={party}
      location={activeLocation}
      onVictory={handleVictory}
      onDefeat={handleDefeat}
    />
  );

  return null;
}
