# Chronicles of Aethermarch

> *"A city runs on power. Power runs on something else."*

A story-driven JRPG built with React, inspired by Final Fantasy V, VII, and X. Set in a sprawling steampunk/magitek city-state where a rogue AI engine is consuming the world's energy — and four unlikely people are the only ones who can stop it.

---

## 🎮 Current Features

- **Cinematic cutscene engine** — typewriter text, atmospheric CSS backgrounds, scene transitions, character nameplates, and title cards
- **Turn-based battle system** — job classes, skills, HP/MP, enemy encounters
- **Job/class system** — 6 jobs including Knight, Machinist, Arcanist, Medic, Rogue, Gunner
- **AI-powered battle narration** — Claude API generates dynamic steampunk flavor text
- **World map** — explorable locations with atmospheric backgrounds

---

## 🧑‍🤝‍🧑 The Party

| Character | Job | Role |
|-----------|-----|------|
| **Vyx** | Machinist → Hexblade | Protagonist. Grief operating as anger. |
| **Kael** | Hexblade (unique) | Vyx's brother. Part machine, part human. |
| **Pip** | Rogue / Ghost Protocol | Chaos energy hiding something tender. |
| **Ryker** | Knight / Atonement | A good man trying to become one again. |

---

## 🌆 The World

**Aethermarch** is a vertical industrial city-state built on centuries of magitek innovation. The **Aethon Syndicate** controls its energy infrastructure through the **Hex Engine** — a self-learning AI that required human subjects to reach full capacity. The Engine has gone rogue. The Syndicate is covering it up. The monsters in the lower districts used to be people.

---

## 🛠️ Tech Stack

- **React** + **Vite**
- **CSS animations** — no external animation libraries
- **Anthropic Claude API** — AI battle narration
- **Google Fonts** — Press Start 2P, VT323, Cinzel, IM Fell English, Share Tech Mono

---

## 🚀 Running Locally

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/chronicles-of-aethermarch.git
cd chronicles-of-aethermarch

# Install dependencies
npm install

# Add your Anthropic API key in src/scenes/BattleScreen.jsx
# Find: "x-api-key": "YOUR_KEY_HERE"

# Run
npm run dev
```

Open [http://localhost:5173](http://localhost:5173)

---

## 🗺️ Roadmap

- [x] Scene 01 — "Something In The Wreckage"
- [x] Cutscene engine with typewriter effect
- [x] Turn-based battle system
- [x] Job/class system
- [ ] Scene 02 — "District 7" + first tutorial battle
- [ ] Town screen with shop system
- [ ] Level up system
- [ ] Job ability inheritance (FFV-style)
- [ ] Full story Act 1

---

## 📖 Story & Design

Built as a passion project and AI engineering portfolio piece. Story, characters, and world design by **Skitz**. Technical implementation assisted by **Claude (Anthropic)**.

---

*Living document — updated as the game develops.*
