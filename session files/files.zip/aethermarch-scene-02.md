# CHRONICLES OF AETHERMARCH
## Scene 02 — "The Weight of District 7"
### Lower District 7 | Pre-dawn, continuous from Scene 01

---

> **SCRIPT FORMAT GUIDE**
> `[SCENE]` — what the player sees on screen
> `[SOUND]` — audio/ambient description
> `[VYX]` — Vyx speaking (dialogue box, portrait left)
> `[NARRATION]` — text on screen, no portrait
> `[TUTORIAL]` — tutorial prompt box (distinct visual style)
> `(beat)` — a pause, a moment, let it breathe
> `(hard cut)` — no transition, immediate scene change

---

---

## PART ONE: THE STREETS BEFORE SUNRISE

---

[SCENE]
*Vyx emerges from the collapsed substation into the pre-dawn streets of Lower District 7. The air is thick — not just with smog, but with something heavier. Absence. The street that should be waking up isn't. Shuttered windows. A food cart abandoned mid-setup, canvas still tied down. A child's shoe in the middle of the road.*
*The aether conduits beneath the cobblestones still pulse their faint blue. The city's veins, keeping time.*

[SOUND]
*Distant pressure hiss from a cracked pipe somewhere. Wind through empty streets. The occasional flicker of a dying light fixture overhead.*

[VYX]
*"Three weeks ago this block had forty families on it."*

*(beat)*

[SCENE]
*He walks slowly, not heading anywhere in particular yet. Taking it in. His eyes move over the details — a quarantine notice half-torn from a doorframe, the symbol underneath it scratched out with something sharp. A window on the second floor, curtain moving. Someone still here. Someone still watching.*

[VYX]
*"Syndicate called it a voluntary evacuation. Put it in the official report and everything."*

*(beat)*

[VYX]
*"Nobody volunteered."*

[SCENE]
*He passes a wall covered in names. Handwritten, in different colors of paint, different hands. Some neat, some desperate. Some with dates beneath them. He slows. Doesn't stop. He's seen it before. That doesn't make it easier.*

[NARRATION]
*The wall has been here for two months. It gets longer every week.*

*(beat)*

[VYX — quietly, not really to himself, not really to anyone]*
*"Hey, Mrs. Orveil. Still got that pot you lent me."*

*(beat — long)*

[SCENE]
*He keeps walking. Passes a Syndicate monitoring tower — automated, no human operator. Its sensor array sweeps the street in slow arcs. Red light. Red light. Red light.*
*Vyx steps into a doorway without thinking. Pure reflex. Waits for the sweep to pass.*

[VYX]
*"Yeah. Still doing that. Two years later, still doing that."*

*(beat)*

[SCENE]
*The sweep passes. He steps back out. Looks up at the tower for a moment — something behind his eyes that isn't quite anger and isn't quite grief. Something that's been living in the space between those two things for a long time.*

[VYX]
*"Dad used to say the Syndicate wasn't evil. Just... indifferent. Said indifference at scale was worse."*

*(beat)*

[VYX]
*"I used to argue with him about that."*

*(beat)*

[VYX — almost a whisper]*
*"I don't anymore."*

[SCENE]
*He turns a corner. His workshop is two blocks ahead — a converted storage unit on the ground floor of a half-collapsed building. Home, more or less. The aether coil in his bag presses against his back. Rent. Actually rent.*
*For just a moment, the weight lifts a little. He almost smiles.*

[VYX]
*"Okay. Two blocks. Don't get weird, don't get—"*

---

## PART TWO: THE AMBUSH

---

*(hard cut)*

[SCENE]
*Something slams into him from the left.*
*Not a tackle — a strike. Magitek-enhanced, fast, wrong. He hits the cobblestones hard, bag skidding away. The aether coil rolls out.*
*He's already rolling, already on his feet — the survival instinct of someone who's been living in a quarantine zone for two years. Wrench in hand before he's fully upright.*

[SOUND]
*That crackling static. Loud now. Close.*

[SCENE]
*A HEX WRAITH stands between him and his workshop.*
*Different from the one in the substation. That one paused. Flickered. This one has no hesitation — it's already moving, already orienting, signal burning at full intensity. The hollow blue eyes don't recognize anything. There's nothing left in there to recognize.*

[VYX]
*"Okay. OKAY."*

*(beat)*

[VYX]
*"Don't panic. You've seen these. You know how they work. Probably."*

---

## PART THREE: THE TUTORIAL

---

[TUTORIAL — distinct box, different visual style from dialogue]
*⚙ COMBAT INITIATED*
*Vyx has entered battle with a Hex Wraith.*
*Press ▶ to continue.*

---

[VYX]
*"Alright. First thing — don't just swing. You swing wild at one of these things, you hit the lattice wrong and it conducts straight back through the wrench. Ask me how I know."*

[TUTORIAL]
*⚙ TAKING TURNS*
*Combat in Aethermarch is turn-based. You and your enemies act in order of SPEED.*
*Faster characters act more often. Vyx is quick — he'll usually go first.*
*Press ▶ to continue.*

---

[VYX]
*"You've got options every turn. Basic attack — wrench to whatever's exposed. Costs nothing, does something. Not glamorous but it keeps you alive."*

[TUTORIAL]
*⚙ ATTACK*
*Every character can ATTACK each turn at no cost.*
*Damage depends on your ATK stat minus the enemy's DEF.*
*It won't always be pretty. It'll always be something.*
*Press ▶ to continue.*

---

[VYX]
*"Then there's the gear. Machinist stuff — I've got a drill bit attachment on this wrench that punches through armor plating. Costs aether to use. That blue bar under my HP? That's my MP. Magitek Points. Run out and I'm down to bare metal."*

[TUTORIAL]
*⚙ SKILLS & MP*
*Each character has SKILLS — special abilities that cost MP to use.*
*MP is shown as the blue bar beneath HP.*
*Skills are more powerful than basic attacks but use limited resources.*
*Manage MP carefully — you can't recover it mid-battle.*
*Press ▶ to continue.*

---

[VYX]
*"The Wraith's got a weak point — the magitek lattice joints on its left shoulder. Hit those and the signal stutters. Disrupts its attack pattern. In a real fight that matters. In a tutorial it matters more."*

[TUTORIAL]
*⚙ ENEMY WEAKNESSES*
*Some enemies have exploitable patterns.*
*Hex Wraiths are vulnerable to DRILL SHOT — armor-piercing attacks that bypass their plating.*
*Watch the enemy's HP bar. When it drops below 25%, their behavior changes.*
*Press ▶ to continue.*

---

[VYX]
*"One more thing. If it gets bad — and it can get bad fast — I can use the environment. Debris, cover, distance. Out here it's just me and a wrench and whatever's in my bag. So I don't get to lose."*

[TUTORIAL]
*⚙ STAYING ALIVE*
*If Vyx's HP reaches zero, the battle is lost.*
*HP does not recover between turns — every hit counts.*
*Use SKILLS strategically. A Drill Shot now might prevent two attacks later.*
*You've got this. Probably.*
*Press ▶ to begin.*

---

## PART FOUR: THE FIGHT

---

[SCENE]
*The Wraith lunges.*

[VYX]
*"RIGHT — HERE WE GO—"*

---

*[ PLAYER TAKES CONTROL — BATTLE BEGINS ]*

---

*[ BATTLE RESOLUTION — plays after player wins ]*

---

[SCENE]
*The Wraith collapses. Its signal spikes once — violent, desperate — then flatlines. The blue light in its eyes dims to nothing. The magitek lattice goes dark.*
*Vyx stands over it, breathing hard. Wrench raised. Waiting to see if it gets back up.*
*It doesn't.*

*(beat)*

[VYX]
*"Okay."*

*(beat)*

[VYX]
*"Okay, that's — yeah. That's how that works."*

[SCENE]
*He lowers the wrench. Looks at his hand. Still not shaking. He's not sure if that's good or bad anymore.*
*He picks up the aether coil from the cobblestones. Still intact. He looks at it for a moment.*

[VYX — quietly]*
*"Still rent."*

*(beat)*

[SCENE]
*He walks the last two blocks to his workshop. Unlocks the heavy door. Steps inside.*
*The workshop is small and dense — shelves of salvaged magitek parts, a workbench covered in half-finished repairs, a cot in the corner that's more organized than it looks. A place that someone lives in carefully.*
*He drops his bag. Drops onto the bench. Stares at the ceiling.*

[VYX]
*"Two in one morning. That's new."*

*(beat)*

[VYX]
*"That Wraith in the substation. The way it looked at me."*

*(beat)*

[VYX]
*"Things don't look at you. They just... come at you. That's the whole thing about them."*

*(beat — long)*

---

## PART FIVE: THE MESSAGE

---

[SCENE]
*Something on his workbench catches his eye. A small magitek transmitter — the kind used for short-range encrypted signals. It's not his. He would know if it was his.*
*It's blinking.*

[VYX]
*"...That's not mine."*

*(beat)*

[VYX]
*"That is definitely not mine."*

[SCENE]
*He picks it up carefully. Turns it over. No markings. Decent craftsmanship — not Syndicate issue, not black market junk either. Someone built this themselves. Someone who knew what they were doing.*
*He presses the receive button.*

[SOUND]
*Static. Then a voice — young, fast, already mid-sentence.*

---

[PIP — via transmitter, voice only, slightly distorted]*
*"—okay so I know what you're thinking, you're thinking 'who put this in my workshop' and that is a FAIR question, very reasonable, I respect it—"*

*(beat)*

[PIP]
*"The answer is me. I put it there. About an hour ago actually, you were out way longer than I expected, did something happen? Actually don't answer that, I saw the Wraith, you're welcome for not helping, I had a scheduling conflict—"*

*(beat)*

[VYX — staring at the transmitter]*
*"...Who is this."*

[PIP]
*"Right, yes, introductions. I'm Pip. I've been watching you for about three weeks. Not in a weird way. In a professional way. I'm a professional."*

*(beat)*

[VYX]
*"A professional what."*

[PIP]
*"That's a great question and we can absolutely discuss it, but first — the Wraith in the substation. The one that stopped."*

*(beat — longer)*

[PIP — quieter now, the fast-talk dropping just slightly]*
*"I've been watching these things for six months. Running every scan Glitch can manage. And they don't stop. They don't recognize people. They don't — they just don't do what that one did."*

*(beat)*

[PIP]
*"So. You want to tell me what that was about? Because I have some thoughts. And some data. And a theory that is either very smart or very stupid and I genuinely cannot tell which."*

*(beat)*

[VYX — looking at the transmitter for a long moment]*
*"...How do I know this isn't a Syndicate trap?"*

[PIP]
*"You don't! Great instinct, very healthy paranoia, love that for you. But if I was Syndicate I'd have cleaner equipment and worse jokes. Meet me at the old transit junction on 7th. One hour."*

*(beat)*

[PIP]*
*"Bring the wrench."*

[SOUND]
*Click. Transmission ends.*

*(beat — long)*

[SCENE]
*Vyx sits in his workshop holding the transmitter. Looks at the door. Looks at the transmitter. Looks at the door.*

[VYX]
*"...I hate this already."*

*(beat)*

[SCENE]
*He picks up his wrench. Puts it back on his belt.*
*He goes.*

---

## END OF SCENE 02

---

> **NEXT:** Scene 03 — "Glitch"
> *The transit junction on 7th. Vyx finds Pip before he sees her — or rather, Glitch finds him first. A small, sparking drone drops from the ceiling and scans him before Pip drops down after it. She's exactly what her voice suggested. The conversation that follows will change what Vyx thinks he knows about the Wraith in the substation.*

---

*— Script continues as story develops —*
*Last updated: Session 2*
